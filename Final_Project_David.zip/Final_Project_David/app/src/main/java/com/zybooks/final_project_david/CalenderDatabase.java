package com.zybooks.final_project_david;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class CalenderDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CalenderApp.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "Users";
    public static final String  TABLE_EVENTS = "Events";

    public CalenderDatabase(Context context){
        super(context, DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + "( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT UNIQUE, " +
                "password TEXT, " +
                "name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + "( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_email TEXT, " +
                "event_name TEXT, " +
                "event_time TEXT, " +
                "event_description TEXT, " +
                "reminder INTEGER)");




    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE_USERS);
        db.execSQL("drop table if exists " + TABLE_EVENTS);
        onCreate(db);
    }

    public boolean insertUser(String email, String password, String name){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("name", name);

        long result = db.insert(TABLE_USERS,null, contentValues);
        return result != -1;
    }

    public boolean insertEvent(String userEmail, String eventName, String eventTime, String eventDescription, boolean reminder){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("user_email", userEmail);
        contentValues.put("event_name", eventName);
        contentValues.put("event_time", eventTime);
        contentValues.put("event_description", eventDescription);
        contentValues.put("reminder", reminder ? 1 : 0);

        long result = db.insert(TABLE_EVENTS,null, contentValues);
        return result != -1;
    }
    public int checkLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM Users WHERE email = ? AND password = ?", new String[]{email, password});

        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            cursor.close();
            return userId;
        } else {
            cursor.close();
            return -1;
        }
    }

    public String getName(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name FROM Users WHERE id = ?", new String[]{String.valueOf(id)});

        String name = null;
        if (cursor.moveToFirst()) {
            name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
        }

        cursor.close();
        return name;
    }

    public String getEventsForDate(int userId, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder events = new StringBuilder();


        Cursor userCursor = db.rawQuery("SELECT email FROM Users WHERE id = ?", new String[]{String.valueOf(userId)});
        String email = null;
        if (userCursor.moveToFirst()) {
            email = userCursor.getString(userCursor.getColumnIndexOrThrow("email"));
        }
        userCursor.close();

        if (email == null) {
            return "";
        }


        Cursor cursor = db.rawQuery(
                "SELECT event_name, event_description FROM Events WHERE user_email = ? AND event_time = ?",
                new String[]{email, date});

        if (cursor.moveToFirst()) {
            do {
                String event_name = cursor.getString(0);
                String description = cursor.getString(1);

                events.append("• ").append(event_name);
                if (description != null && !description.isEmpty()) {
                    events.append(": ").append(description);
                }
                events.append("\n\n");
            } while (cursor.moveToNext());
        }
        cursor.close();

        return events.toString().trim();
    }

    public String getEmailFromId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT email FROM Users WHERE id = ?", new String[]{String.valueOf(id)});

        String email = null;
        if (cursor.moveToFirst()) {
            email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
        }
        cursor.close();
        return email;
    }


    public List<Event> getEventListForDate(int userId, String date) {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id, event_name, event_time, event_description FROM Events WHERE user_email = ? AND event_time = ?", new String[]{String.valueOf(userId), date});

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String time = cursor.getString(2);
            String description = cursor.getString(3);

            events.add(new Event(id, name, time, description));
        }
        cursor.close();
        return events;
    }



    public boolean deleteEvent(String eventName, String eventTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_EVENTS, "event_name = ? AND event_time = ?", new String[]{eventName, eventTime});
        return rowsAffected > 0;
    }


}
