package com.zybooks.final_project_david;

import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class CalenderPage extends AppCompatActivity implements addEventDialogFragment.OnEventEnteredListener{
    int userId;
    private CalenderDatabase calenderDatabase;
    @Override
    public void onEventEntered(String eventText) {
        Toast.makeText(this, "New Event: " + eventText, Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        calenderDatabase = new CalenderDatabase(this);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calender_page);
        userId = getIntent().getIntExtra("USER_ID", -1);
        FloatingActionButton fab = findViewById(R.id.floatingActionButton3);
        fab.setOnClickListener(v -> {
            addEventDialogFragment dialog = new addEventDialogFragment();
            dialog.show(getSupportFragmentManager(), "AddEventDialog");
        });

        CalenderDatabase calenderDatabase = new CalenderDatabase(this);

        String name = calenderDatabase.getName(userId);
        Toast.makeText(CalenderPage.this, name, Toast.LENGTH_SHORT).show();



        CalendarView calendarView = findViewById(R.id.calendarView);
        TextView eventTextView = findViewById(R.id.textView5);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String selectedDate = (month + 1) + "/" + dayOfMonth + "/" + year;


            String eventsForDate = calenderDatabase.getEventsForDate(userId, selectedDate);
            LinearLayout eventContainer = findViewById(R.id.eventContainer);
            eventContainer.removeAllViews();

            List<Event> events = calenderDatabase.getEventListForDate(userId, selectedDate);

            if (events.isEmpty()) {
                Toast.makeText(CalenderPage.this, "No events on this date!", Toast.LENGTH_SHORT).show();
            } else {
                for (Event event : events) {
                    View card = getLayoutInflater().inflate(R.layout.event_card, eventContainer, false);

                    TextView eventName = card.findViewById(R.id.eventNameText);
                    TextView timeText = card.findViewById(R.id.timeText);
                    ImageButton deleteButton = card.findViewById(R.id.deleteButton);

                    eventName.setText(event.name);
                    timeText.setText(event.time);

                    deleteButton.setOnClickListener(v -> {
                        calenderDatabase.deleteEvent(event.id);
                        eventContainer.removeView(card);
                        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                    });

                    eventContainer.addView(card);
                }
            }

        });






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onEventEntered(String eventName, String eventDate, String eventDescription, boolean hasReminder) {
        String userEmail = calenderDatabase.getEmailFromId(userId);

        if (userEmail != null) {
            boolean success = calenderDatabase.insertEvent(userEmail, eventName, eventDate, eventDescription, hasReminder);

            if (success) {
                Toast.makeText(this, "Event saved for: " + eventDate, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to Save Event.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "User email not found.", Toast.LENGTH_SHORT).show();
        }
    }

}