package com.zybooks.final_project_david;

public class Event {
    public int id;
    public String name;
    public String time;
    public String description;

    public Event(int id, String name, String time, String description) {
        this.id = id;
        this.name = name;
        this.time = time;
        this.description = description;
    }
}
