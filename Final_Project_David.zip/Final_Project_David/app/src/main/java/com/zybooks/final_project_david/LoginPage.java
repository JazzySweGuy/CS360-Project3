package com.zybooks.final_project_david;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_page);

        Button signUpButton = findViewById(R.id.SignUpButton);
        EditText emailInput = findViewById(R.id.EmailInput);
        EditText passwordInput = findViewById(R.id.PasswordInput);
        Button login = findViewById(R.id.LoginButton);

        CalenderDatabase calenderDatabase = new CalenderDatabase(this);
        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginPage.this, SignUpPage.class);
            startActivity(intent);
        });

        login.setOnClickListener(v ->{
            int userId = calenderDatabase.checkLogin(emailInput.getText().toString(),passwordInput.getText().toString());
            if(userId != -1){
                Intent intent = new Intent(LoginPage.this,CalenderPage.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
                finish();
            }else{
                Toast.makeText(LoginPage.this,"Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        });





        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}