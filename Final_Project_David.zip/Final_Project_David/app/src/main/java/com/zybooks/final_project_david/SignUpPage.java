package com.zybooks.final_project_david;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SignUpPage extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);
        EdgeToEdge.enable(this);

        EditText emailInput = findViewById(R.id.EmailInput_SignUp);
        EditText nameInput = findViewById(R.id.NameInput_SignUp);
        EditText passwordInput = findViewById(R.id.PasswordInput_SignUp);
        EditText reenterPasswordInput = findViewById(R.id.ReEnterPassInput_SignUp);
        Button signUpButton = findViewById(R.id.SignUpButton_SignUp);
        CalenderDatabase calenderDatabase = new CalenderDatabase(this);

        signUpButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString();
                String name = nameInput.getText().toString();
                String password = passwordInput.getText().toString();
                String rePassword = reenterPasswordInput.getText().toString();

                if (email.isEmpty() || name.isEmpty() || password.isEmpty() || rePassword.isEmpty()){
                    Toast.makeText(SignUpPage.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else if(!password.equals(rePassword)) {
                    Toast.makeText(SignUpPage.this, "Passwords don't match", Toast.LENGTH_SHORT).show();
                } else {
                    boolean success = calenderDatabase.insertUser(email,password,name);
                    if(success){
                        Toast.makeText(SignUpPage.this, "Registration successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SignUpPage.this, LoginPage.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        }

        );



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}