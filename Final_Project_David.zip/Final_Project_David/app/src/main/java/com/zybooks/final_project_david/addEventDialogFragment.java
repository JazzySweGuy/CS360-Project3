package com.zybooks.final_project_david;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;

import java.util.Calendar;

public class addEventDialogFragment extends DialogFragment {

    public interface OnEventEnteredListener {
        void onEventEntered(String eventText);

        void onEventEntered(String eventName, String eventDate, String eventDescription, boolean hasReminder);
    }

    private OnEventEnteredListener mListener;

    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.fragment_add_event, null);

        EditText nameEditText = view.findViewById(R.id.eventNameEditText);
        EditText dateEditText = view.findViewById(R.id.eventDateEditText);
        EditText descriptionEditText = view.findViewById(R.id.eventDescriptionEditText);
        CheckBox reminderCheckBox = view.findViewById(R.id.reminderCheckBox);
        Button confirmButton = view.findViewById(R.id.confirmButton);

        dateEditText.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(requireActivity(),
                    (DatePicker view1, int year1, int month1, int dayOfMonth) -> {
                        String selectedDate = (month1 + 1) + "/" + dayOfMonth + "/" + year1;
                        dateEditText.setText(selectedDate);
                    }, year, month, day);
            datePickerDialog.show();
        });


        confirmButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString().trim();
            String date = dateEditText.getText().toString().trim();
            String description = descriptionEditText.getText().toString().trim();
            boolean hasReminder = reminderCheckBox.isChecked();

            if (name.isEmpty() || date.isEmpty()) {

                nameEditText.setError("Required");
                dateEditText.setError("Required");
            } else {

                if (mListener != null) {
                    mListener.onEventEntered(name, date, description, hasReminder);
                }
                dismiss();
            }
        });


        builder.setView(view);

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnEventEnteredListener) {
            mListener = (OnEventEnteredListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnEventEnteredListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
